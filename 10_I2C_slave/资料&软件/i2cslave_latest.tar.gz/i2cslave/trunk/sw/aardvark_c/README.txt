
Windows gcc-mingw32:
1) Install GCC MinGW32.
   The latest version can be downloaded from the MinGW website:
   http://www.mingw.org/
2) Install MSYS
   The latest version can be downloaded from the MinGW website:
   http://www.mingw.org/
3) Type 'make' at the MSYS command line
4) _output/PROGRAM


